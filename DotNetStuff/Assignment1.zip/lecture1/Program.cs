﻿using System;

namespace DotNetStuff
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("My name is Caleb Carlton");

            Console.WriteLine("\n");


            Console.WriteLine("{0}", "CCCCCCCCCCCCCCCCCCCC");
            Console.WriteLine("{0}         {1}  {1}", "CC", "##");
            Console.WriteLine("{0}      {1}", "CC", "############");
            Console.WriteLine("{0}         {1}  {1}", "CC", "##");
            Console.WriteLine("{0}      {1}", "CC", "############");
            Console.WriteLine("{0}         {1}  {1}", "CC", "##");
            Console.WriteLine("{0}", "CCCCCCCCCCCCCCCCCCCC");

            Console.WriteLine("\n");


            Console.WriteLine("Name: Caleb Carlton");
            Console.WriteLine("Graduation Year: 2024");
            Console.WriteLine("School: Chattanooga State Community College");

            Console.WriteLine("\n");

            Console.WriteLine("*********************************************");            
            Console.WriteLine("** Programming Assignment # 1              **");            
            Console.WriteLine("** Developer: Caleb Carlton                **");
            Console.WriteLine("** Date Submitted: 08 / 16 / 2023          **");
            Console.WriteLine("** Purpose: Provide internal documentation **");
            Console.WriteLine("*********************************************");


            Console.WriteLine("\n");

            Console.WriteLine("************************************************");           
            Console.WriteLine("** Name: Caleb Carlton                        **");           
            Console.WriteLine("** Hometown: West Haven, CT                   **");           
            Console.WriteLine("** Major: Cybersecurity, Programming          **");           
            Console.WriteLine("** Hobby: Gaming, Computer programming, Chess **");            
            Console.WriteLine("** Favorite Activity: Playing Video Games     **");
            Console.WriteLine("************************************************");      

            Console.ReadKey();


        }
    }
}