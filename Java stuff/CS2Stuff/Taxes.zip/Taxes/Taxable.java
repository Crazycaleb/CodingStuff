package Taxes;

public interface Taxable {
    double getTaxable();
}
